# Wireshark Display Filters

## DNS
dns

## HTTP
http

## ARP
arp

## ICMP
icmp

## SSH
tcp.port == 22

## TCP SYN
tcp.flags.syn == 1
